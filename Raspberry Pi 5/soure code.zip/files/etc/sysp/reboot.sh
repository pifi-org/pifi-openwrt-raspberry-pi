#!/bin/sh
# This script will reboot the OpenWrt device
reboot
